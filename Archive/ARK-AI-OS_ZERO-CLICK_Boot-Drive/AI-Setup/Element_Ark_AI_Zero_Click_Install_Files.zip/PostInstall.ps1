# POST-INSTALL: Ultimate AI Workstation (Element Ark)
# [snipped: use block from earlier]

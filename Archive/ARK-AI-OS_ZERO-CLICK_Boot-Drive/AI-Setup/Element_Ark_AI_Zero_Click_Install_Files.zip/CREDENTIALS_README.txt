Windows/PC Admin:
User: FlexNetOS
Password: Ai@2030!
Login passkey: 112219

Microsoft 365 Business:
User: david@de-flex.net
Password: Ayden0413!

Personal Microsoft Account:
User: revenaugh.david@gmail.com
Password: Burntheships*2019

Docker Desktop:
Email: flexnetos@de-flex.net
Password: FlexNetOS2030
Docker PAT: dckr_pat_rDY4hZ2CpIkwEXwVvAtv4t3qajA

GitHub:
Username: FlexNetOS
Email: flexnetos@de-flex.net
Password: FlexNetOS2030

WSL/Ubuntu 22.04:
User: ARK-AI
Password: Ai@2030!

Microsoft Product Key:
KWBNQ-7YY26-PJWGG-MP4DC-TMT6T

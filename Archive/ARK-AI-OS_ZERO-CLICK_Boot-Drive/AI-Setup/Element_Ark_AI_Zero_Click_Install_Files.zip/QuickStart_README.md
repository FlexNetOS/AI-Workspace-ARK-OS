# Quick Start Guide – Automated Windows 11 Pro AI Workstation (Element Ark / FlexNetOS)
# [see detailed markdown block above]
